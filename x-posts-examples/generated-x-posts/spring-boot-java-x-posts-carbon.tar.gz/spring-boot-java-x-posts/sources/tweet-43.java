Double.parseDouble(numStr.replaceAll(",", "."));
